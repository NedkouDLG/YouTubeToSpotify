client_id = "51995574b41043fdb1d0ca6b92f0cc1e"
client_secret = "f006e36e443648e7b67c6fad1317a8d0"
redirect_uri = "http://127.0.0.1:8080"
